﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HospitalManagementEntityy
{
  public  class Rooom
    {
        

        public int RoomNo { get; set; }

        public int RommId { get; set; }

    }
}
