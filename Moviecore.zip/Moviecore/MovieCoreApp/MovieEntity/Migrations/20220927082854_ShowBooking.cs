﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace MovieEntity.Migrations
{
    public partial class ShowBooking : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "ID",
                table: "theatres",
                newName: "Id");

            migrationBuilder.RenameColumn(
                name: "Addres",
                table: "theatres",
                newName: "Address");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "Id",
                table: "theatres",
                newName: "ID");

            migrationBuilder.RenameColumn(
                name: "Address",
                table: "theatres",
                newName: "Addres");
        }
    }
}
