﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Text;
using MovieEntity.Model;

namespace MovieEntity.Data
{
    public class MovieDbContext:DbContext
    {
        public DbSet<Movie> movies { get; set; }
        public DbSet<Theatre> theatres { get; set; }
        public DbSet<ShowTiming> showtimings{ get; set; }
        protected override void OnConfiguring(DbContextOptionsBuilder dbContextOptionsBuilder)
        {
            dbContextOptionsBuilder.UseSqlServer("Data Source=VDC01LTC2151;Initial Catalog=BookMovieShowDb;Integrated Security=True;");
        }

    }
}
