﻿using Microsoft.EntityFrameworkCore;
using MovieEntity.Data;
using MovieEntity.Model;
using System;
using System.Collections.Generic;
using System.Text;
using MovieEntity.Data;
using System.Linq;

namespace MovieEntity.BookMyshow
{
    //    public class Movieoperation
    //    {
    //        MovieDbContext db = null;

    //        public string AddMovie(Movie movie)
    //        {
    //            db = new MovieDbContext();
    //            db.movies.Add(movie);
    //            db.SaveChanges();
    //            return "Inserted";
    //        }
    //        public string UpdateMovie(Movie movie)

    //        {
    //            db.movies.Add(movie);
    //            db.Entry(movie).State = EntityState.Modified;
    //            db.SaveChanges();


    //            return "update";
    //        }
    //        public string DeletMOvie(Movie movieId)

    //        {
    //            Movie movieobj = db.movies.Find(movieId);
    //            db.Entry(movieobj).State = EntityState.Modified;
    //            db.SaveChanges();
    //            return "delete";

    //        }
    //        public List<Movie> ShowAll(String type)
    //        {
    //            db = new MovieDbContext();
    //            List<Movie> movelist = db.movies.ToList();
    //            //linq
    //            var result = from movies in movelist
    //                         where movies.MovieType == type
    //                         select new Movie
    //                         {
    //                             Id = movies.Id,
    //                             Name = movies.Name
    //                         };
    //            return movelist;
    //            List<Movie> movieResult = new List<Movie>();

    //        }
    //        public void ShowAllMovies()
    //        {
    //            Movieoperation movieOperations = new Movieoperation();
    //            Console.WriteLine("Enter the movie ");
    //            List<Movie> movies = movieOperations.ShowAll(type);
    //            foreach (var item in movies)
    //            {
    //                Console.WriteLine("Id:" + item.Id);
    //                Console.WriteLine("Name:" + item.Name);
    //                Console.WriteLine("Descriptions:" + item.MovieDesc);
    //                Console.WriteLine("Type:" + item.MovieType);



    //            }
    //            public Movie ShowMovieByid(int moveId)
    //            {
    //                db = new MovieDbContext();
    //                Movie movie = db.movies.Find(moveId);
    //                return movie;

    //            }
    //            public List<Movie> ShowByType(String type)
    //            {
    //                db = new MovieDbContext();
    //                List<Movie> movelist = db.movies.ToList();
    //                //linq
    //                var result = from movies in movelist
    //                             where movies.MovieType == type
    //                             select new Movie
    //                             {
    //                                 Id = movies.Id,
    //                                 Name = movies.Name
    //                             };
    //                return movelist;
    //                List<Movie> movieResult = new List<Movie>();



    //            }
    //        }
    //    }

    //}

    
        public class Movieperation
        {
            MovieDbContext db = null;
            public string AddMovie(Movie movie)
            {
                db = new MovieDbContext();
                db.movies.Add(movie);
                db.SaveChanges();

                return "Movie Added Succesfully";
            }
            public string UpdateMovie(Movie movie)
            {

                db = new MovieDbContext();
                db.Entry(movie).State = EntityState.Modified;
                db.SaveChanges();

                return "Movie Updated Succesfully";
            }
            public string DeleteMovie(int movieId)
            {

                db = new MovieDbContext();
                Movie movieObj = db.movies.Find(movieId);
                db.Entry(movieObj).State = EntityState.Deleted;
                db.SaveChanges();

                return "Movie Deleted Succesfully";
            }
            public List<Movie> ShowAllMovie()
            {

                db = new MovieDbContext();
                List<Movie> movieList = db.movies.ToList();

                return movieList;
            }

            public List<Movie> ShowMovieByType(string type)
            {
                db = new MovieDbContext();
                List<Movie> movieList = db.movies.ToList();

                //Linq query- select * from movie where movietype='type'
                var result = from movies in movieList
                             where movies.MovieType == type
                             select new Movie
                             {
                                 Id = movies.Id,
                                 Name = movies.Name,
                             };
                List<Movie> movieResult = new List<Movie>();
                foreach (var item in result) // Linq Query execution
                {
                    movieResult.Add(item);

                }
                return movieResult;
            }

            public Movie ShowMovieById(int movieId)
            {

                db = new MovieDbContext();
                Movie movie = db.movies.Find(movieId);

                return movie;
            }

        }
    }
