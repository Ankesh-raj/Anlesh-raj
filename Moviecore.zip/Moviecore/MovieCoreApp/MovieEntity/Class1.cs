﻿using System;

namespace MovieEntity
{
    public class Class1
    {
    }
}
