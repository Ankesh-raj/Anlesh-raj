﻿using System;

namespace BookMyshowEntityLayer
{
    public class Class1
    {
    }
}
