﻿using BookMyShowDataLayer;
using BookMyshowEntityLayer;
using System;
using System.Collections.Generic;
using System.Text;

namespace BookMyshowPresentationLayer
{
    public class TheratrePl
    {
        public void MenuPL()
        {
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("Enter 1 to Add Theatre \n" +
                "Enter 2 to Update Theatre \n" +
                "Enter 3 to Delete Theatre \n " +
                "Enter 4 to Show All Theatre \n" +
                "Enter 5 to Show Theatre By Id \n" +
                "Enter 6 to Show Theatre By Type \n" +
                "Enter  to Exit"
                );

            int enter = Convert.ToInt32(Console.ReadLine());
           // MoviePL moviePLObj = new MoviePL();
            TheratrePl theratrePlObj = new TheratrePl();

            switch (enter)
            {
                case 1:
                    theratrePlObj.AddTheratrePl();
                    theratrePlObj.MenuPL();
                    break;
                //case 2:
                //    moviePLObj.UpdateMoviePL();
                //    moviePLObj.MenuPL();
                //    break;
                //case 3:
                //    moviePLObj.DeleteMoviePL();
                //    moviePLObj.MenuPL();
                //    break;
                //case 4:
                //    moviePLObj.ShowAllMoviesPL();
                //    moviePLObj.MenuPL();
                //    break;
                //case 5:
                //    moviePLObj.ShowMovieByIdPL();
                //    moviePLObj.MenuPL();
                //    break;
                //case 6:
                //    moviePLObj.ShowMovieByTypePL();
                //    moviePLObj.MenuPL();
                //    break;
                default:
                    Console.WriteLine("Better Luck Next Time :)");
                    break;
            }
        }
        public void AddTheratrePl()
        {
            TheraterOperation theraterOperation = new TheraterOperation();
           // Movieperation movieOperationsObj = new Movieperation();
            Theatre therateobj = new Theatre();
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.WriteLine("Enter Therater Name: ");
            therateobj.Name = Console.ReadLine();
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.WriteLine("Enter Address: ");
            therateobj.Address = Console.ReadLine();
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.WriteLine("Enter : ");
           therateobj.Comments = Console.ReadLine();
            Console.ForegroundColor = ConsoleColor.White;

            string msg =theraterOperation.AddTherater(therateobj);
            Console.WriteLine(msg);
        }

        public void UpdateTheratrePL()
        {
            TheraterOperation theraterOperation = new TheraterOperation();
            Movieperation movieOperationsObj = new Movieperation();
            Theatre therateobj = new Theatre();
           // Movie movieObj = new Movie();
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.WriteLine("Enter MovieId: ");

            therateobj.Id = Convert.ToInt32(Console.ReadLine());
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.WriteLine("Enter MovieName: ");
            Console.ForegroundColor = ConsoleColor.Blue;
            therateobj.Name = Console.ReadLine();
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.WriteLine("Enter Movie Description: ");
            therateobj.Address = Console.ReadLine();
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.WriteLine("Enter Movie Type: ");
            therateobj.Address = Console.ReadLine();

            string msg = theraterOperation.UpdateTheratre(therateobj);
            Console.WriteLine(msg);
        }
        public void DeleteTheratrePL()
        {

           // Movieperation movieOperationsObj = new Movieperation();
            //Movie movieObj = new Movie();

            Console.WriteLine("Enter MovieId: ");
            int movieId = Convert.ToInt32(Console.ReadLine());

            string msg =th.DeleteMovie(movieId);
            Console.WriteLine(msg);
        }


        public void ShowAllTheraterPL()
        {
            Movieperation movieOperationsObj = new Movieperation();
            List<Movie> movieList = movieOperationsObj.ShowAllMovie();

            foreach (var item in movieList)
            {
                Console.WriteLine("Id: " + item.Id);
                Console.WriteLine("Name: " + item.Name);
                Console.WriteLine("Description: " + item.MovieDesc);
                Console.WriteLine("Type: " + item.MovieType);
            }
        }

        public void ShowTheraterByTypeId()
        {
            Movieperation movieOperationsObj = new Movieperation();
            Console.WriteLine("Enter MovieId: ");
            int movieId = Convert.ToInt32(Console.ReadLine());
            Movie movie = movieOperationsObj.ShowMovieById(movieId);

            Console.WriteLine(movie.Name);
            Console.WriteLine(movie.MovieDesc);
            Console.WriteLine(movie.MovieType);
        }

        public void ShowTheratreByTypePL()
        {
            Movieperation movieOperationsObj = new Movieperation();
            Console.WriteLine("Enter MovieType: ");
            string movieType = Console.ReadLine();
            List<Movie> movieList = movieOperationsObj.ShowMovieByType(movieType);

            foreach (var item in movieList)
            {
                Console.WriteLine("Id: " + item.Id);
                Console.WriteLine("Name: " + item.Name);
                /*                Console.WriteLine("Description: " + item.MovieDesc);
                                Console.WriteLine("Type: " + item.MovieType);*/
            }

            /*Console.WriteLine(movie.Name);
            Console.WriteLine(movie.MovieDesc);
            Console.WriteLine(movie.MovieType);*/


        }
    }
}
