﻿using System;
using System.Collections.Generic;
using System.Text;
using BookMyShowDataLayer;
using BookMyshowEntityLayer;

namespace BookMyshowPresentationLayer
{
    public class MoviePL
    {

        public void MenuPL()
        {
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("Enter 1 to Add Movie \n" +
                "Enter 2 to Update Movie \n" +
                "Enter 3 to Delete Movie \n " +
                "Enter 4 to Show All Movie \n" +
                "Enter 5 to Show Movie By Id \n" +
                "Enter 6 to Show Movie By Type \n" +
                "Enter  to Exit"
                );

            int enter = Convert.ToInt32(Console.ReadLine());
            MoviePL moviePLObj = new MoviePL();

            switch (enter)
            {
                case 1:
                    moviePLObj.AddMoviePL();
                    moviePLObj.MenuPL();
                    break;
                case 2:
                    moviePLObj.UpdateMoviePL();
                    moviePLObj.MenuPL();
                    break;
                case 3:
                    moviePLObj.DeleteMoviePL();
                    moviePLObj.MenuPL();
                    break;
                case 4:
                    moviePLObj.ShowAllMoviesPL();
                    moviePLObj.MenuPL();
                    break;
                case 5:
                    moviePLObj.ShowMovieByIdPL();
                    moviePLObj.MenuPL();
                    break;
                case 6:
                    moviePLObj.ShowMovieByTypePL();
                    moviePLObj.MenuPL();
                    break;
                default:
                    Console.WriteLine("Better Luck Next Time :)");
                    break;
            }
        }
        public void AddMoviePL()
        {
            Movieperation movieOperationsObj = new Movieperation();
            Movie movieObj = new Movie();
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.WriteLine("Enter MovieName: ");
            movieObj.Name = Console.ReadLine();
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.WriteLine("Enter Movie Description: ");
            movieObj.MovieDesc = Console.ReadLine();
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.WriteLine("Enter Movie Type: ");
            movieObj.MovieType = Console.ReadLine();
            Console.ForegroundColor = ConsoleColor.White;

            string msg = movieOperationsObj.AddMovie(movieObj);
            Console.WriteLine(msg);
        }

        public void UpdateMoviePL()
        {
            Movieperation movieOperationsObj = new Movieperation();
            Movie movieObj = new Movie();
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.WriteLine("Enter MovieId: ");

            movieObj.Id = Convert.ToInt32(Console.ReadLine());
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.WriteLine("Enter MovieName: ");
            Console.ForegroundColor = ConsoleColor.Blue;
            movieObj.Name = Console.ReadLine();
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.WriteLine("Enter Movie Description: ");
            movieObj.MovieDesc = Console.ReadLine();
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.WriteLine("Enter Movie Type: ");
            movieObj.MovieType = Console.ReadLine();

            string msg = movieOperationsObj.UpdateMovie(movieObj);
            Console.WriteLine(msg);
        }
        public void DeleteMoviePL()
        {

            Movieperation movieOperationsObj = new Movieperation();
            //Movie movieObj = new Movie();

            Console.WriteLine("Enter MovieId: ");
            int movieId = Convert.ToInt32(Console.ReadLine());

            string msg = movieOperationsObj.DeleteMovie(movieId);
            Console.WriteLine(msg);
        }


        public void ShowAllMoviesPL()
        {
            Movieperation movieOperationsObj = new Movieperation();
            List<Movie> movieList = movieOperationsObj.ShowAllMovie();

            foreach (var item in movieList)
            {
                Console.WriteLine("Id: " + item.Id);
                Console.WriteLine("Name: " + item.Name);
                Console.WriteLine("Description: " + item.MovieDesc);
                Console.WriteLine("Type: " + item.MovieType);
            }
        }

        public void ShowMovieByIdPL()
        {
            Movieperation movieOperationsObj = new Movieperation();
            Console.WriteLine("Enter MovieId: ");
            int movieId = Convert.ToInt32(Console.ReadLine());
            Movie movie = movieOperationsObj.ShowMovieById(movieId);

            Console.WriteLine(movie.Name);
            Console.WriteLine(movie.MovieDesc);
            Console.WriteLine(movie.MovieType);
        }

        public void ShowMovieByTypePL()
        {
            Movieperation movieOperationsObj = new Movieperation();
            Console.WriteLine("Enter MovieType: ");
            string movieType = Console.ReadLine();
            List<Movie> movieList = movieOperationsObj.ShowMovieByType(movieType);

            foreach (var item in movieList)
            {
                Console.WriteLine("Id: " + item.Id);
                Console.WriteLine("Name: " + item.Name);
                /*                Console.WriteLine("Description: " + item.MovieDesc);
                                Console.WriteLine("Type: " + item.MovieType);*/
            }

            /*Console.WriteLine(movie.Name);
            Console.WriteLine(movie.MovieDesc);
            Console.WriteLine(movie.MovieType);*/


        }






    }
}
