﻿using BookMyshowPresentationLayer;

namespace BookMyShow

{
    internal class Program
    {
        static void Main(string[] args)
        {
            MoviePL moviePL = new MoviePL();
            // moviePL.ShowMovieByTypePL();
            //  moviePL.ShowAllMoviesPL();
           // moviePL.MenuPL();
           TheratrePl theratrePl = new TheratrePl();
            theratrePl.AddTheratrePl();

            //   movieBL.ShowAllMovies();
            //List<int> values = new List<int>()
            //{
            //    23,34,56,676,67,34,78,5
            //};
            //var result=from obj in values  where obj<50  select obj;
            //foreach (var item in result)
            //{
            //    Console.WriteLine(item);
            //}



        }
    }
}
