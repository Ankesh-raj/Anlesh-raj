﻿using BookMyshowEntityLayer;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BookMyShowDataLayer
{
    public class TheraterOperation
    {
        MovieDbContext db = null;
        public string AddTherater(Theatre theatre)
        {
            db = new MovieDbContext();
            db.theatres.Add(theatre);
            db.SaveChanges();

            return "Therater Added Succesfully";
        }
        public string UpdateTheratre(Theatre theatre)
        {

            db = new MovieDbContext();
            db.Entry(theatre).State = EntityState.Modified;
            db.SaveChanges();

            return "Therater Updated Succesfully";
        }
        public string DeleteTherater(int theraterId)
        {

            db = new MovieDbContext();
            Theatre theraterobj1 = db.theatres.Find(theraterId);
            db.Entry(theraterobj1).State = EntityState.Deleted;
            db.SaveChanges();

            return "Therater Deleted Succesfully";
        }
        public List<Theatre> ShowAllTherater()
        {

            db = new MovieDbContext();
            List<Theatre> theatrelist = db.theatres.ToList();

            return theatrelist;
        }

        public List<Theatre> ShowTheraterByType(string name)
        {
            db = new MovieDbContext();
            List<Theatre> theatrelist = db.theatres.ToList();

            //Linq query- select * from movie where movietype='type'
            var result = from theatre in theatrelist
                         where theatre.Name == name
                         select new Theatre
                         {
                             Id = theatre.Id,
                             Name = theatre.Name,
                         };
            List<Theatre> movieResult = new List<Theatre>();
            foreach (var item in result) // Linq Query execution
            {
                movieResult.Add(item);

            }
            return movieResult;
        }

        public Theatre ShowTheraterById(int theraterId)
        {

            db = new MovieDbContext();
            Theatre theatre = db.theatres.Find(theraterId);

            return theatre;
        }

    }
}
