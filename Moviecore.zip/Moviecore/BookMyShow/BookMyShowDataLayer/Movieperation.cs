﻿using BookMyshowEntityLayer;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BookMyShowDataLayer
{
    public class Movieperation
    {
        MovieDbContext db = null;
        public string AddMovie(Movie movie)
        {
            db = new MovieDbContext();
            db.movies.Add(movie);
            db.SaveChanges();

            return "Movie Added Succesfully";
        }
        public string UpdateMovie(Movie movie)
        {

            db = new MovieDbContext();
            db.Entry(movie).State = EntityState.Modified;
            db.SaveChanges();

            return "Movie Updated Succesfully";
        }
        public string DeleteMovie(int movieId)
        {

            db = new MovieDbContext();
            Movie movieObj = db.movies.Find(movieId);
            db.Entry(movieObj).State = EntityState.Deleted;
            db.SaveChanges();

            return "Movie Deleted Succesfully";
        }
        public List<Movie> ShowAllMovie()
        {

            db = new MovieDbContext();
            List<Movie> movieList = db.movies.ToList();

            return movieList;
        }

        public List<Movie> ShowMovieByType(string type)
        {
            db = new MovieDbContext();
            List<Movie> movieList = db.movies.ToList();

            //Linq query- select * from movie where movietype='type'
            var result = from movies in movieList
                         where movies.MovieType == type
                         select new Movie
                         {
                             Id = movies.Id,
                             Name = movies.Name,
                         };
            List<Movie> movieResult = new List<Movie>();
            foreach (var item in result) // Linq Query execution
            {
                movieResult.Add(item);

            }
            return movieResult;
        }

        public Movie ShowMovieById(int movieId)
        {

            db = new MovieDbContext();
            Movie movie = db.movies.Find(movieId);

            return movie;
        }







    }
}
