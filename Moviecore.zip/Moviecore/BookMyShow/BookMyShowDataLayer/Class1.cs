﻿using System;

namespace BookMyShowDataLayer
{
    public class Class1
    {
    }
}
