﻿using System;

namespace BookMyshowBusineseLayer
{
    public class Class1
    {
    }
}
