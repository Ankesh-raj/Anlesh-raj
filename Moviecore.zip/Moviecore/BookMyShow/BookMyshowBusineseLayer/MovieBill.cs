﻿using System;
using System.Collections.Generic;
using System.Text;
using BookMyShowDataLayer;
using BookMyshowEntityLayer;

namespace BookMyshowBusineseLayer
{
    public  class MovieBill
    {
        Movieperation movieperation = new Movieperation();
    
        public void AddMoviePL()
        {
            
        }

    }
}
