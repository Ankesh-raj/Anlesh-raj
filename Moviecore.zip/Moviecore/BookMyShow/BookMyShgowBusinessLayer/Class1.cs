﻿using System;

namespace BookMyShgowBusinessLayer
{
    public class Class1
    {
    }
}
