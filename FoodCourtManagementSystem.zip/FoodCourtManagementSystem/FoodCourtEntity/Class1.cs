﻿using System;

namespace FoodCourtEntity
{
    public class Class1
    {
    }
}
