﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FoodManagementPresentation
{
    public class ItemPl
    {
        public void menu()
        {
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("Manage Food Items\n" +
             "1) Press 1 to Adding New Food Item\n" +
             "2)Press 2 to Edit  the Exiting Food items Doctor\n" +
             "3)Press 3 to view details of the Food\n" +
             "4)Press 4 to listing of all food");
            Console.ForegroundColor = ConsoleColor.White;
            int codeentered;
            codeentered = Convert.ToInt32(Console.ReadLine());

            //switch (codeentered)
            //{
            //    case 1:
            //        adminPLObj = new AdminPL();
            //        adminPLObj.AdminLogin();
            //        break;
            //    case 2:
            //        DoctorPL userPLObj = new DoctorPL();
            //        userPLObj.DoctorLogin();
            //        break;
            //    case 3:
            //        PatientPL patientPLObj = new PatientPL();
            //        patientPLObj.PatientLogin();
            //        break;
            //    default:
            //        Console.ForegroundColor = ConsoleColor.Red;
            //        Console.WriteLine("Invalid Code");
            //        break;
            //}
        }
    }
}
