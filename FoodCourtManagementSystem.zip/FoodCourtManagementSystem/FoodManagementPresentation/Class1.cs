﻿using System;

namespace FoodManagementPresentation
{
    public class Class1
    {
    }
}
