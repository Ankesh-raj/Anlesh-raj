﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FoodManagementPresentation
{
    public class ReportPl
    {
        public void menu()
        {
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("Report of the Project Food Court Management System\n" +
             "1) Press 1 to Report of all Food Items\n" +
             "2)Press 2 to Report of a Food Category\n" +
             "3)Press 3 to Report of all sales\n");
          
            Console.ForegroundColor = ConsoleColor.White;
            int codeentered;
            codeentered = Convert.ToInt32(Console.ReadLine());

            //switch (codeentered)
            //{
            //    case 1:
            //        adminPLObj = new AdminPL();
            //        adminPLObj.AdminLogin();
            //        break;
            //    case 2:
            //        DoctorPL userPLObj = new DoctorPL();
            //        userPLObj.DoctorLogin();
            //        break;
            //    case 3:
            //        PatientPL patientPLObj = new PatientPL();
            //        patientPLObj.PatientLogin();
            //        break;
            //    default:
            //        Console.ForegroundColor = ConsoleColor.Red;
            //        Console.WriteLine("Invalid Code");
            //        break;
            }
        }
}
