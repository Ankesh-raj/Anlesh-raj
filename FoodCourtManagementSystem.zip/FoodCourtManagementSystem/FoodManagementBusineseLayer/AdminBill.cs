﻿using System;
using System.Collections.Generic;
using System.Text;
using FoodManagementDataLayer;
using FoodManagementEntity;


namespace FoodManagementBusineseLayer
{
    public class AdminBill

    {
        public bool AdminLogin(string adminEmail, string adminPassword)
        {
            bool flag = false;
            AdminDal adminDALObj = new AdminDal();
            // adminDALObj.GetAllAdminsDAL();
            List<Admin> Admins1 = adminDALObj.GetAllAdminsDAL();

            foreach (var item in Admins1)
            {
                if (item.AdminEmail == adminEmail && item.AdminPassword == adminPassword)
                {
                    flag = true;
                    break;
                }


            }
            return flag;
        }
    }
}
