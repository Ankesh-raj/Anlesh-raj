﻿using System;

namespace FoodManagementBusineseLayer
{
    public class Class1
    {
    }
}
