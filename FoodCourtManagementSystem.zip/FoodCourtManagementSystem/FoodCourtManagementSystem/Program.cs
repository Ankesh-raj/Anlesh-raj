﻿using System;
using FoodManagementPresentation;

namespace FoodCourtManagementSystem
{
    public class Program
    {
        static void Main(string[] args)
        {
            AdminPl adminPLObj = new AdminPl();
            adminPLObj.AdminLogin();
        }
    }
}
