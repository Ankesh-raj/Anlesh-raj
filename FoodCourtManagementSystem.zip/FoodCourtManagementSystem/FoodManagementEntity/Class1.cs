﻿using System;

namespace FoodManagementEntity
{
    public class Class1
    {
    }
}
