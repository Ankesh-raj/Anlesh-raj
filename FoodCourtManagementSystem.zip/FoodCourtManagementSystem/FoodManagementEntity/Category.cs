﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace FoodManagementEntity
{
    public class Category

    {
        [Key]

        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]

        public int CategoryId { get; set; }


        public  string  Categoryname{ get; set; }

        [ForeignKey("item")]
        public int ItemId { get; set; }
        public Item item { get; set; }

        public string CategoryType{ get; set; }

    

    }
}
