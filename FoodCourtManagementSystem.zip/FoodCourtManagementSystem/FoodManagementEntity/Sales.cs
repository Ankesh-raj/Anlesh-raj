﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace FoodManagementEntity
{
    public class Sales

    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int SalesId { get; set; }

        [ForeignKey("item")]
        public int ItemId { get; set; }

        public Item item { get; set; }
        public string SalesQuantity { get; set; }
        public string SalesCost{ get; set; }




    }
}
