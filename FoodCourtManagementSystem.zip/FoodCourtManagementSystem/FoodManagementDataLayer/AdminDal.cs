﻿using FoodManagementEntity;
using System;
using System.Collections.Generic;
using System.Text;

namespace FoodManagementDataLayer
{
    public class AdminDal
    {
        public List<Admin> Admins = new List<Admin>();

        Admin admin1 = new Admin("a", 1, "Ankesh", "111@");
        Admin admin2 = new Admin("kiran@gmail", 2, "kiran", "56789@");

        public List<Admin> GetAllAdminsDAL()
        {
            Admins.Add(admin1);
            Admins.Add(admin2);



            return Admins;
    }   }
}
