﻿using System;

namespace FoodManagementDataLayer
{
    public class Class1
    {
    }
}
