﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Text;
using FoodManagementEntity;

namespace FoodManagementDataLayer
{
    public class FoodDBcontextv

    {
        public class MovieDBcontextv : DbContext
        {
            public DbSet<Item> item { get; set; }
            public DbSet<Category> category { get; set; }
            public DbSet<Sales> sales { get; set; }

            protected override void OnConfiguring(DbContextOptionsBuilder dbContextOptionsBuilder)
            {
                dbContextOptionsBuilder.UseSqlServer("Data Source=VDC01LTC2151;Initial Catalog=FoodManagement;Integrated Security=True;");
            }
        }
    }
}
