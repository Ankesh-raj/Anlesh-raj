﻿using LibraryManagementData;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LibraryManagementData;
using LibraryManagementEntity;
namespace LibraryManagementBusinese
{
    public  class UserBill
    {



        UserDal userdalobj = new UserDal();
        public string AddDoctorBLL(User user)
        {


            string msg = userdalobj.AddUserDAL(user);
            return msg;
        }

        public List<User> ShowAllDoctorDALBLL()
        {
            List<User> user = userdalobj.ShowAllUserDAL();

            return user;

        }

        public string RemoveUserBLL(int UserId)
        {


            string msg = userdalobj.DeleteUserDAL(UserId);
            return msg;

        }

        public string UpdateUserBLL(User user)
        {


            string msg = userdalobj.UpadateUserDAl(user);
            return msg;

        }





    }
}
