﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LibraryManagementEntity;
using LibraryManagementBusinese;

namespace LibraryManagementPresentation
{
    public  class UserPl
    {

        public void AddUser()
        {
            User user = new User();
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("Enter user details");
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.Write("User Id :");
            user.UserId = Convert.ToInt32(Console.ReadLine());
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.Write("User Name :");
            user.Username = Console.ReadLine();
            Console.Write("Doctor Email :");
            Console.ForegroundColor = ConsoleColor.Blue;
            user.Usermail = Console.ReadLine();
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.Write("Doctor Password :");
            user.UserPassword = Console.ReadLine();
            Console.ForegroundColor = ConsoleColor.Blue;


            UserBill userbillObj = new UserBill();
            string msg = userbillObj.AddDoctorBLL(user);

            Console.WriteLine(msg);
            UserPl userplObj = new UserPl();
            userplObj.AdminUserSection();

        }

        public void UpdateUser()
        {
            User user = new User();
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("Enter The  User details");
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.Write("Enter the User Id :");
            user.UserId = Convert.ToInt32(Console.ReadLine());
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.Write("Enter the User Name :");
            user.Username = Console.ReadLine();
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.Write("Enter the User Email :");
            user.Usermail= Console.ReadLine();
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.Write("Enter the Password :");
            user.UserPassword = Console.ReadLine();
            Console.ForegroundColor = ConsoleColor.Blue;

            UserBill userbillObj = new UserBill();
            string msg = userbillObj.UpdateUserBLL(user);
          
      

            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine(msg);
            UserPl userplObj = new UserPl();
            userplObj.AdminUserSection();

        }

        public void ShowAllUser()
        {
            UserBill userbillObj = new UserBill();
          
            List<User> doctors = userbillObj.ShowAllDoctorDALBLL();
            Console.ForegroundColor = ConsoleColor.DarkYellow;
            Console.WriteLine("-------------------------------userlist--------------------------------------------------------");
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("--Id-----------Name-----------------Email----------------------Password--------------");
            Console.ForegroundColor = ConsoleColor.DarkYellow;
            Console.WriteLine("----------------------------------------------------------------------------------------------------");

            foreach (var item in doctors)
            {

                Console.WriteLine("  " + item.UserId + " \t" + item.Username.PadLeft(12) + " \t\t" + item.Usermail.PadLeft(8) + "\t\t" + item.UserPassword.PadLeft(17));

            }
            UserPl userplObj = new UserPl();
            userplObj.AdminUserSection();
        }
    

        public void RemoveUser()
        {

            UserBill userbillObj = new UserBill();
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("Enter Doctor Details");
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.WriteLine("Doctor Id :");
            Console.ForegroundColor = ConsoleColor.Blue;
            int UserId = Convert.ToInt32(Console.ReadLine());

            string msg = userbillObj.RemoveUserBLL(UserId);
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine(msg);
            Console.Read();

            UserPl userplObj = new UserPl();
            userplObj.AdminUserSection();

        }

        public bool AdminUserSection()
        {
            UserPl userplObj = new UserPl();
            bool flag1 = true;
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("Welcome-t0---user -Section");
            int input;
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.WriteLine("Press 1 to add a User");
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.WriteLine("Press 2 to update a User");
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.WriteLine("Press 3 to delete a User");
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.WriteLine("Press 4 to show all User");
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.WriteLine("Press 5 to exit");
            Console.ForegroundColor = ConsoleColor.White;
            input = Convert.ToInt32(Console.ReadLine());

            switch (input)
            {
                case 1:

                    userplObj.AddUser();

                    break;

                case 2:
                    userplObj.UpdateUser();

                    break;
                case 3:
                    userplObj.RemoveUser(); ;

                    break;
                case 4:
                    userplObj.ShowAllUser(); ;

                    break;
                case 5:
                    flag1 = false;
                    break;
                default:
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("invalid code");
                    break;

            }

            return flag1;


        }
    }
}


