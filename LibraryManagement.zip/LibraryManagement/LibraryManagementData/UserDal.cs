﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LibraryManagementEntity;
using System.Data.SqlClient;
using System.Data;

namespace LibraryManagementData
{
    public class UserDal
    {
        public List<RecivedBook> RecivedBooks;
        public List<RequestedBook> RequestedBooks;
        public List<User> users;





        public static string sqlcon = "Data Source=DESKTOP-2AJ3ULQ\\SQLEXPRESS; Initial Catalog=LibraryManagementSystem; Integrated Security=True;";
        public List<User> user = new List<User>();



        public string AddUserDAL(User user)
        {
            string msg = "";
            SqlConnection con = new SqlConnection(sqlcon);
            SqlCommand cmd = new SqlCommand("insert into User1 values(" + user.UserId + ",'" + user.Username + "','" + user.Usermail + "','" + user.UserPassword+ "')", con);
            con.Open();
            int row = cmd.ExecuteNonQuery();
            con.Close();
            if (row > 0)
            {
                msg = "user Inserted successfully";
            }
            return msg;
        }



        public string UpadateUserDAl(User user)
        {
            string msg = "";
            SqlConnection conn = new SqlConnection(sqlcon);
            SqlCommand cmd = new SqlCommand("Update User1 set UserId=" + user.UserId + ",Username='" +user.Username + "',Usermail='" + user.Usermail + "',UserPassword='" + user.UserPassword + "'where  UserId=" + user.UserId, conn);
            conn.Open();
            int row = cmd.ExecuteNonQuery();
            conn.Close();
            if (row > 0)
            {
                msg = "user Updated successfull";
            }



            return msg;
        }



        public string DeleteUserDAL(int UserId)
        {
            string msg = "";
            SqlConnection conn = new SqlConnection(sqlcon);
            SqlCommand cmd = new SqlCommand("Delete from User1  where UserId =" + UserId, conn);
            conn.Open();
            int row = cmd.ExecuteNonQuery();
            conn.Close();
            if (row > 0)
            {
                msg = "User Deleted Successfully,...  :)";
            }



            return msg;
        }



        public List<User> ShowAllUserDAL()
        {
            SqlConnection conn = new SqlConnection(sqlcon);
            SqlDataAdapter adp = new SqlDataAdapter("Select * from User1 ", conn);
            DataTable dt = new DataTable();
            List<User> user = new List<User>();
            adp.Fill(dt);



            if (dt != null && dt.Rows.Count > 0)
            {
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    user.Add(new User
                    {
                        UserId = Convert.ToInt32(dt.Rows[i]["UserId"]),
                        Username = dt.Rows[i]["Username"].ToString(),
                        Usermail = dt.Rows[i]["Usermail"].ToString(),
                        UserPassword = dt.Rows[i]["UserPassword"].ToString(),
                       
                    });
                }
            }



            return user;
        }
    }
}


































        //public List<RequestedBook> AcceptReuestDal()
        //{
        //    return RequestedBooks;


        //}
        //public List<User> AddUserDal()
        //{
        //    return Users;


        //}
        //public List<RecivedBook> DeleteRecivedDal()
        //{
        //    return RecivedBooks;


        //}
        //public List<User> GetAllUsersDal()
        //{
        //  return Users;


        //    }
        //    public List<User> GetRecivedBookDal()
        //    {
        //        return Users;


        //    }
        //    public List<User> GetRequestedBookDal()
        //    {
        //        return Users;


        //    }
        //    public List<User> RemovelUsersDal()
        //    {
        //        return Users;


        //    }
        //    public List<User> RequestBookDal()
        //    {
        //        return Users;


        //    }
        //    public List<User> UpdatUsereDal()
        //    {
        //        return Users;


        //    }

        //}
//    }
//}
