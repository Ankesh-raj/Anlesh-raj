﻿namespace BookMyShowCoreEntity
{
    public class Class1
    {

    }
}